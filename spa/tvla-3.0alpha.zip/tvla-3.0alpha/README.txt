In order to run TVLA please set the TVLA_HOME environment 
variable to point to this TVLA home directory and run the
appropriate script file (tvla.bat, tvla or tvla.bash).

Java Runtime Environment 1.5 has to be installed before
running TVLA.

DISCLAIMER: This version of TVLA is in active development,
and not a finished release. Use at you own discretion.
Features and behaviour may change in final release.