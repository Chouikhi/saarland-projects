typedef struct t {
		int data;
		struct t *left ;
		struct t *right;
} Tree ;